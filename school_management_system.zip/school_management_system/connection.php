<?php 
$conn=mysql_connect('localhost', 'root', '');
$sel=mysql_select_db('vision');


?>

